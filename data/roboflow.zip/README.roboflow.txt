
Dice - v2 medium-color
==============================

This dataset was exported via roboflow.ai on August 2, 2020 at 4:42 AM GMT

It includes 359 images.
Dice are annotated in COCO format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 756x1008 (Stretch)

No image augmentation techniques were applied.


